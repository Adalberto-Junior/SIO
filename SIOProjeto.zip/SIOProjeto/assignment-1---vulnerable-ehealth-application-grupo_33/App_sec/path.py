from io import BytesIO
from flask import Blueprint, render_template, request, redirect, flash, send_file
from models import *
from flask_login import login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash

bp_user = Blueprint("utilizador", __name__, template_folder="templates")

@bp_user.route('/')
def index():
    return  render_template('index.html', user = current_user)

@bp_user.route('/about')
def about():
    return  render_template('about.html', user = current_user)

@bp_user.route('/contact')
def contact():
    db.create_all()
    if request.method == 'POST':
        queryTopic = request.form.get('querytopic')
        phone = request.form.get('phone')
        message = request.form.get('message')
        if current_user:
          user =  User.query.filter_by(id=current_user.id).first()
          fullname = user.name + user.last_name
          email = user.email
          new_message = Message(Fullname = fullname, email = email, queryTopic = queryTopic, cellNumber = phone, messager = message, user_id=user_id)
          db.session.add(new_message)
          db.session.commit()
          flash("Message sent!", category = 'success')
        else:
            fullname = request.form.get('fullname')
            email = request.form.get('email')
            new_message = Message(Fullname = fullname, email = email, queryTopic = queryTopic, cellNumber = phone, messager = message) 
            db.session.add(new_message)
            db.session.commit()
            flash("Message sent!", category = 'success')
    return  render_template('contact.html' , user = current_user)

@bp_user.route('/service')
def service():
    return  render_template('service.html', user = current_user)

@bp_user.route('/doctor')
def doctor():
    return  render_template('doctor.html' , user = current_user)

@bp_user.route('/appointment', methods = ['GET'])
@login_required
def appointment():
    if request.method == 'GET':
        return  render_template('appointment.html', user = current_user)
            

@bp_user.route('/confirmation')
@login_required
def confirmation():
    return  render_template('confirmation.html')

@bp_user.route('/blog', methods=['GET' , 'POST' ])
@login_required
def blog():
    db.create_all()
    posts = Post.query.all()
    print(posts)
    return render_template ('blog.html', user = current_user, posts = posts)



@bp_user.route('/post/<int:id>', methods=['GET' , 'POST'])
def post(id):

    if request.method == 'POST':
        print('post')
        name = request.form.get('name')
        message = request.form.get('comment')
        date = datetime.now()
        post_id = id
        db.session.connection()
        new = Comment(message = message,author = name, post_id = post_id,date = date)
        db.session.add(new)
        db.session.commit()
    
    post = Post.query.filter_by(id = id).one()
    messages = Comment.query.filter_by(post_id = id).all()
    return render_template('blog-single.html',user = current_user, post = post, comments = messages)

@bp_user.route('/login' , methods=['GET' , 'POST' ])
def login():
    if request.method == 'GET':
        return render_template("login.html")
    if request.method == 'POST':
        user_name = request.form.get('user_name')
        password  = request.form.get('password')

        user =  User.query.filter_by(user_name=user_name).first()
        if user:
            if check_password_hash(user.password, password):
                login_user(user, remember = True)
                if user.user_name == 'Admin':
                    return redirect("Admin")
                return redirect("costumer")
            else:
                 flash("Incorrect Password, try again", category = "error")
        else:
             flash("User name does not exist", category="error")
    
    return  render_template('login.html')
@bp_user.route('/costumer', methods=['GET' , 'POST' ])
@login_required
def costumer():
    return render_template("costumer.html", user = current_user)


@bp_user.route('/sigin', methods=['GET' , 'POST' ])
def sigin():

    if request.method == 'GET':
        return render_template("sigin.html")

    if request.method == 'POST':
        name      = request.form.get('name')
        last_name = request.form.get('last_name') 
        user_name = request.form.get('user_name')
        email     = request.form.get('email')
        password  = request.form.get('password')
        type_user = request.form.get('type_user')

    
        user  =  User.query.filter_by(email=email).first()
        user1 =  User.query.filter_by(user_name = user_name).first()

        if user:
            flash("Email alread exist.",category = "error")
            return render_template("sigin.html")
        if user1:
            flash("User Name alread exist.",category = "error")
            return render_template("sigin.html")

        new = User(name, last_name,user_name,email,password = generate_password_hash(password, method = 'sha256'),type_user= type_user)
        db.session.add(new)
        db.session.commit()

    flash("Account Created", category="Success")
    return redirect("login")
    
@bp_user.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect("login")

@bp_user.route('/Admin')
@login_required
def listTable():
    user = User.query.all()
    return render_template("show_base.html",user = user)


@bp_user.route('/delete/<int:id>', methods=['GET' , 'POST' ])
@login_required
def delete(id):
    user = User.query.get(id)
    if request.method == 'GET':
        return render_template("confirm.html", user = user)
    if request.method == 'POST':
        db.session.delete(user)
        db.session.commit()
        return redirect("/Admin")

@bp_user.route('/message')
def seeMessage():
    user = User.query.all()
    return render_template("message.html",user = user)

@bp_user.route('/upload' , methods=['GET' , 'POST' ])
def upload():
    db.create_all()
    if request.method == 'GET':
        return render_template("upload.html")
    if request.method == 'POST':
        file = request.files['file']
        user_id = request.form.get('user_id')
        ficheiro = Upload(filename=file.filename,data=file.read(),user_id=user_id)
        db.session.add(ficheiro)
        db.session.commit()
        flash("File Added!", category = "success")
    return render_template("upload.html")

@bp_user.route('/download/<int:user_id>' , methods=['GET' , 'POST' ])
def download(user_id):
    if request.method == 'GET':
        return render_template("download.html", user = current_user)
    download = Upload.query.filter_by(user_id = user_id).first()
    if request.method == 'POST':
        return send_file(BytesIO(download.data), download_name=download.filename ,as_attachment=True) 