from flask_login import UserMixin
from flask_sqlalchemy import SQLAlchemy
from threading import RLock
from copy import deepcopy
from datetime import (datetime,timezone)
#import bcrypt

db = SQLAlchemy() 

class Message(db.Model):
    __tablename__ = "message"
    id = db.Column(db.Integer, primary_key=True)
    Fullname   = db.Column(db.String(100))
    email      = db.Column(db.String(100))
    queryTopic = db.Column(db.String(100))
    cellNumber = db.Column(db.Integer)
    user_id    = db.Column(db.Integer,db.ForeignKey('User.id'))
    messager   = db.Column(db.String(1000))
    
    
    def __init__(self, Fullname, email,  queryTopic, cellNumber,  user_id, messager ):
        self.Fullname   = Fullname
        self.queryTopic = queryTopic
        self.cellNumber = cellNumber
        self.email      = email
        self.user_id    = user_id
        self.messager   = messager
    def __repr__(self):
        return "Message: {}".format(self.messager)

class Upload(db.Model):
    __tablename__ = "Ficheiro"
    id = db.Column(db.Integer, primary_key=True)
    filename   = db.Column(db.String(50))
    data = db.Column(db.LargeBinary)
    user_id    = db.Column(db.Integer,db.ForeignKey('User.id'))  
    
    def __init__(self, filename, data, user_id):
        self.filename = filename
        self.data = data
        self.user_id    = user_id
    def __repr__(self):
        return "Message: {}".format(self.filename)

class User(db.Model,UserMixin):
    __tablename__ = "User"
    id = db.Column(db.Integer, primary_key=True)
    name      = db.Column(db.String(100))
    last_name = db.Column(db.String(100))
    user_name = db.Column(db.String(100))
    email     = db.Column(db.String(100))
    password  = db.Column(db.String(100))
    type_user = db.Column(db.String(100))
    message   = db.relationship('Message')
    ficheiro  = db.relationship('Upload')
    def __init__(self, name, last_name, user_name, email, password, type_user):
        self.name      = name
        self.last_name = last_name
        self.user_name = user_name
        self.email     = email
        self.password  = password
        self.type_user = type_user
    
    def __repr__(self):
        return "User: {}".format(self.name,self.last_name,self.type_user)


class Doctors(db.Model,UserMixin):
    __tablename__ = "Doctor"
    id = db.Column(db.Integer, primary_key=True)
    name      = db.Column(db.String(100))
    last_name = db.Column(db.String(100))
    user_name = db.Column(db.String(100))
    email     = db.Column(db.String(100))
    password  = db.Column(db.String(100))
    type_user  = db.Column(db.String(100))

    def __init__(self, name, last_name, user_name, email, password, type_user):
        self.name      = name
        self.last_name = last_name
        self.user_name = user_name
        self.email     = email
        self.password  = password
        self.type_user = type_user
    
    def __repr__(self):
        return "Doctor: {}".format(self.name,self.last_name,self.type_user)
#####-----------------------------------------------------------------------------------------------

def now():
    return datetime.now(timezone.utc)


class Post(db.Model):
    __tablename__ = 'Post'
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100))
    content = db.Column(db.String(100))
    author = db.Column(db.String(100))
    comment_ids = db.Column(db.Integer)
    date = db.Column(db.DateTime)

    def __init__(self, title, content, author, comment_ids=None, date=None):
        self.id = None
        self.title = title
        self.content = content
        self.author = author
        self.comment_ids = comment_ids if comment_ids else []
        self.date = date if date else now()


class Comment(db.Model):
    __tablename__ = 'Comment'
    id = db.Column(db.Integer, primary_key=True)
    message = db.Column(db.String(100))
    author = db.Column(db.String(100))
    post_id = db.Column(db.Integer)
    date = db.Column(db.DateTime)



    def __init__(self, message, author, post_id, date=None):
        self.id = None
        self.message = message
        self.author = author
        self.post_id = post_id
        self.date = date if date else now()





